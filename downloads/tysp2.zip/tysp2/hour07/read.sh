#!/bin/sh

read LINE
echo $LINE
exit $?
