dirs() { 

    OLDIFS="$IFS"         # save IFS (internal field separator)
    IFS=:                 # set  IFS to :, so that we can process
                          # each entry in _DIR_STACK easily
 
    for i in $_DIR_STACK   # print out each entry in _DIR_STACK
      do
            echo "$i \c"
     done

    echo                   # print out new line (makes output pretty)

    IFS="$OLDIFS"         # restore IFS
}

