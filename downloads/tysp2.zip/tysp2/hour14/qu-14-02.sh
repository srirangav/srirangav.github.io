mymkdir() {

    if [ $# -lt 1 ] ; then
        echo "ERROR: Insufficient arguments." >&2
        return 1
    fi

    mkdir -p "$1" > /dev/null 2>&1
    if [ $? -eq 0 ] ; then
        cd "$1" > /dev/null 2>&1
        if [ $? -eq 0 ] ; then
            pwd ;
        else
            echo "ERROR: Could not cd to $1." >&2
        fi
    else
        echo "ERROR: Could not mkdir $1." >&2
    fi
}

