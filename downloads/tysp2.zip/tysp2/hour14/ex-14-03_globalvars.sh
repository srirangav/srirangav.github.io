#!/bin/sh

pearFunc () {
   pear=2;                                  # set $pear
   echo "In pearFunc(): pear is $pear"      # print out its value
}

pearFunc                                    # call pearFunc
echo "Outside of pearFunc(): pear is $pear" # print out $pear

