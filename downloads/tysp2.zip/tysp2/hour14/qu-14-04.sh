readPass () {
    stty -echo
    while : ;
    do
       PASS1=""
       PASS2=""
       echo -n "Enter Password: "
       read PASS1
       if [ -z "$PASS1" ] ; then
          echo
          echo "Error: Password must not be blank. Try again." 1>&2
          continue
       fi
       echo
       echo -n "Enter Password (confirm): "
       read PASS2
       if [ "$PASS1" != "$PASS2" ] ; then
          echo
          echo "Error: Passwords do not match. Try again." 1>&2
          continue;
       fi
       PASS="$PASS1"
       break;
    done 
    stty echo
    echo
}

