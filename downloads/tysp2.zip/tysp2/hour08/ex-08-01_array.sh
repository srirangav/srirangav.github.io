#!/bin/ksh -v

FRUIT[0]=apple
FRUIT[1]=banana
FRUIT[2]=orange
echo ${FRUIT[2]}
echo ${FRUIT[*]}
FRUIT[3]="passion fruit"
echo ${FRUIT[@]}
