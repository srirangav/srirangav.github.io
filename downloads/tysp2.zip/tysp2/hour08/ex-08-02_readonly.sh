#!/bin/sh -v

FRUIT=kiwi
readonly FRUIT
echo $FRUIT
FRUIT=cantaloupe
