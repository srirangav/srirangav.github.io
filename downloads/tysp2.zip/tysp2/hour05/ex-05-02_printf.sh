#!/bin/sh

printf "%16s\t%-16s\n" "Name" "User Name"
printf "%16s\t%-16s\n" "Sriranga" "ranga"
printf "%16s\t%-16s\n" "Srivathsa" "vathsa"

