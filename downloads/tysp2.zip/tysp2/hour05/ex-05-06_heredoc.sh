#!/bin/sh

cat > urls << MYURLS
	http://www.csua.berkeley.edu/~ranga/
	http://www.cisco.com/
	http://www.marathon.org/story/
	http://www.gnu.org/
MYURLS
