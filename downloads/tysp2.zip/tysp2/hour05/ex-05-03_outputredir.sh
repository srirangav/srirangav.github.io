#!/bin/sh

{ date ; uptime ; who ; } > mylog
