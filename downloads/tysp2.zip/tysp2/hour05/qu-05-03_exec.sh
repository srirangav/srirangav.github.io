#!/bin/sh -v

exec 4> out.txt
exec 5>&4 
exec 1>&5
date
