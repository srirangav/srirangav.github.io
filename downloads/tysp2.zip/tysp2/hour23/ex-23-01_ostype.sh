#!/bin/sh

getOSName() {
    case `uname -s` in
        *BSD)
            echo bsd ;;
        Darwin)
            echo darwin ;;
        SunOS)
            case `uname -r` in
                5.*) echo solaris ;;
                  *) echo sunos ;;
            esac
            ;;
        Linux)
            echo linux ;;
        HP-UX)
            echo hpux ;;
        AIX) 
            echo aix ;;
        *) echo unknown ;;
   esac
}

isOS() {
    if [ $# -lt 1 ] ; then
        echo "ERROR: Insufficient Aruments." >&2
        return 1
    fi

    REQ=`echo $1 | tr '[A-Z]' '[a-z]'`
    if [ "$REQ" = "`getOSName`" ] ; then return 0 ; fi
    return 1 
}

