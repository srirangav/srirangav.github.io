getCharCount() {
    case `getOSName` in
        bsd|sunos|linux)
            WCOPT="-c" ;;
        *)
            WCOPT="-m" ;;
    esac

    wc $WCOPT $@
}

