#!/bin/sh
NUMFRUIT="$1"
if [ -z "$NUMFRUIT" ] ; then NUMFRUIT=75 ; fi

awk '
    $3 <= numfruit  { print ; }
' numfruit="$NUMFRUIT" fruit_prices.txt
