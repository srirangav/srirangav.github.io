#!/bin/sh

awk '{ printf "%-15s %s\n" , $1 , $3 ; }' fruit_prices.txt
