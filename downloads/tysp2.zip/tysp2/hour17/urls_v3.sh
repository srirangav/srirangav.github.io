#!/bin/sh
for i in $@ ;
do
    if [ -f "$i" ] ; then
        awk '
            /^ *$/ {file=FILENAME; x+=1 ; next ; }
            END { printf "%s %s %3.1f\n",file,x,(100*(x/NR)); }
        ' "$i"
    else
        echo "ERROR: $i not a file." >&2
    fi
done
