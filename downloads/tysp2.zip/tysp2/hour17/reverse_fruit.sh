#!/bin/sh
awk '{ x=NF ; 
       while (x>0) { 
         printf("%16s ",$x); 
         x-=1;
       } 
       print "" ; 
}' fruit_prices.txt

