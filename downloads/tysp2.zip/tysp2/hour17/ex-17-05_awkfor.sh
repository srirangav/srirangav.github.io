#!/bin/sh
awk '{
    for (x=1;x<=NF;x+=1) {
        printf "%s  ",$x ;
    }
    printf "\n" ;
}' fruit_prices.txt

