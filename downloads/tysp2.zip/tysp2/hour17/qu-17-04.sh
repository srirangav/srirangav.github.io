#!/bin/sh
awk -F: '
    $1 == "B" {
        BAL=$NF ;
        next ;
    }
    $1 == "M" {
        MIN=$NF ;
        next ;
    }
    $1 == "D" {
        BAL += $NF ;
    }
    ($1 == "C") || ($1 == "W") {
        BAL-=$NF ;
    }
    ($1 == "C") || ($1 == "W") || ($1 == "D") {
        printf "%10-s %8.2f",$2,BAL ;
        if ( BAL < MIN ) { printf " * Below Min. Balance" }
        printf "\n" ;
    }
    END {
        printf "-\n%10-s %8.2f\n","Total",BAL ;
    }
' account.txt ;

