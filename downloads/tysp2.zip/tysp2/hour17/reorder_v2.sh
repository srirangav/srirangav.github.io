#!/bin/sh
awk '
    $3 <= 75 { printf "%s\t%s\n",$0,"REORDER" ; }
    $3 > 75 { print $0 ; }
' fruit_prices.txt
