#!/bin/sh

if [ $# -ge 1 ] ; then
   for FILE in $@
   do
       exec 4<&0 < "$FILE"
       while read LINE ; do echo $LINE ; done
       exec 0<&4 4<&-
   done
fi
