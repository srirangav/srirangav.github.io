#!/bin/sh

x=1
until [ $x -ge 10 ] 
do
   echo $x
   x=`expr $x + 1`
done
