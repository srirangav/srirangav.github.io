#!/bin/sh  
# This version of this example that appears on pg 190 doesn't
# work properly:
#
# for FILE in $HOME/.bash*
# do
#     cp $FILE ${HOME}/public_html
#     chmod a+r ${HOME}/public_html/${FILE}
# done
#
# This version fixes the problems.
# 

# NOTE: Remove the following line if you want this script
#       to actually execute the commands 
set -nv

cd 
for FILE in .bash*
do
   cp $FILE ./public_html
   chmod a+r ./public_html/$FILE
done
