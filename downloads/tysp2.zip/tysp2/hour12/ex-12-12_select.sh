#!/bin/sh

CompConf () { echo "You Chose: $@" ; }

select COMPONENT in comp1 comp2 comp3 all none
do
    case $COMPONENT in
        comp1|comp2|comp3) CompConf $COMPONENT ;;
        all) CompConf comp1 
             CompConf comp2
             CompConf comp3
             ;;
        none) break ;;
        *) echo "ERROR: Invalid selection, $REPLY." ;;
    esac
done

