#!/bin/sh

RESPONSE=
while [ -z "$RESPONSE" ] ;
do
   printf "Enter the name of a directory where your files are located: "
   read RESPONSE
   if [ ! -d "$RESPONSE" ] ; then
      echo "ERROR: Please enter a directory pathname."
      RESPONSE=
   fi
done
