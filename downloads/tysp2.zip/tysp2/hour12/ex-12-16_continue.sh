#!/bin/sh

FILES="*"

for FILE in $FILES ;
do
    if [ ! -f "$FILE" ] ; then
        echo "ERROR: $FILE is not a file."
        continue
    fi
    # process the file (we use echo as an example)
    echo "$FILE"
done

