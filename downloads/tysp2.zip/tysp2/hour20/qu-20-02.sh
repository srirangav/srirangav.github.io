Debug() {
    if [ "$DEBUG" = "true" ] ; then
        if [ "$1" = "on"  -o "$1" = "ON" ] ; then
            set -x
        else
            set +x
            echo " >Press Enter To Continue< \c"
            read press_enter_to_continue
        fi
    fi
}

