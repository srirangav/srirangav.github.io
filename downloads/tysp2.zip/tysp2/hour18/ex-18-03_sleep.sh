#!/bin/sh

while :
do
   date
   who
   sleep 300
done >> logfile

