#!/bin/sh

while : 
do
   echo -n "Do you want to play a game (y/n)? "
   read RESPONSE
   case "$RESPONSE" in
      [nN]|no|No|NO) 
         RESPONSE="n" ; break ;;
      [yY]|yes|Yes|YES) 
         RESPONSE="y" ; break ;;
   esac
   echo "Error: Invalid response: '$RESPONSE'"
done 

