#!/bin/sh

unset FRUIT
echo FRUIT is $FRUIT
echo FRUIT is ${FRUIT:=APPLE}
