#!/bin/sh

echo Hello; world
echo Hello\; world
echo You owe $1250
echo You owe \$1250
echo A:\ is my floppy drive
echo A:\\ is my floppy drive
