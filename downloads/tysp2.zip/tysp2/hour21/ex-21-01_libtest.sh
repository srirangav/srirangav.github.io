#!/bin/sh

. $HOME/lib/sh/messages.sh
MSG="hello"
echo_error $MSG
