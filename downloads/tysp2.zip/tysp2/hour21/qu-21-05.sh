################################################
# Name: isUserRoot
# Desc: returns true (0) if the users UID=0
# Args: $1 -> a user name (optional)
################################################

isUserRoot() {
    if [ "`getUID $1`" -eq 0 ] ; then
        return 0
    fi
    return 1
}

