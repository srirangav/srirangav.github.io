#!/bin/sh
echo_error() { echo "ERROR:" $@ >&2 ; }
echo_warning() { echo "WARNING:" $@ >&2 ; }
