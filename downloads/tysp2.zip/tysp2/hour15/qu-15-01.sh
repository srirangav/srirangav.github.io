# NOTE: For Linux or FreeBSD, change the variable PSCMD from
#
#   PSCMD="/bin/ps -ef"
#
# to
#
#   PSCMD="/bin/ps -auwx"

lspids() {

    USAGE="Usage: lspids [-h] process"
    HEADER=false
    PSCMD="/bin/ps -ef"

    case "$1" in
        -h) HEADER=true ; shift ;;
    esac

    if [ -z "$1" ] ; then
        echo $USAGE ;
        return 1 ;
    fi


    if [ "$HEADER" = "true" ] ; then
        $PSCMD 2> /dev/null | head -n 1 ;
    fi

    $PSCMD 2> /dev/null | grep "$1"| grep -v grep
}

