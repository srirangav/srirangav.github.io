#!/bin/sh -v

case $- in
   *i*) # an interactive shell
        PS1="`uname -n`$ "
        PATH="$PATH:/home/bin"
        export PS1 PATH ;;
esac
