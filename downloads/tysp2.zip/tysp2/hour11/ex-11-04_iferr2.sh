#!/bin/sh

if uuencode cherry.gif cherry.gif > cherry.uu ; then
   echo "Encoded cherry.gif to cherry.uu"
else if rm cherry.uu ; then
   echo "Encoding failed, temporary files removed."
else
   echo "Error encoding cherry.gif"
fi
