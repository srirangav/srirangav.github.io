#!/bin/sh

if [ $? -ne 0 ] ; then
   echo "An error was encountered."
   exit
fi
echo "Command was successful." 

