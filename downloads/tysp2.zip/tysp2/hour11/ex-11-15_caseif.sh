#!/bin/sh

if [ "$FRUIT" = apple ] ; then
   echo "Apple pie is quite tasty."
elif [ "$FRUIT" = banana ] ; then
   echo "I like banana nut bread."
else
   echo "New Zealand is famous for kiwi."
fi
