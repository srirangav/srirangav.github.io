trap CleanUp 2 15
trap Init 1
trap "quit=true" 3
PROG="$1"
Init

while : ;
do
    wait $!
    if [ "$quit" = true ] ; then exit 0 ; fi
    $PROG &
done

