#!/bin/sh -v

echo Pomegranates are very juicy > juicy
ln juicy pomegranate
cat pomegranate
rm juicy
cat pomegranate juicy

