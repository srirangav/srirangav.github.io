#include <stdlib.h>
#include <strings.h>
#include <string.h>
#include <stdio.h>

enum {
    SCALE_F = 1,
    SCALE_C = 2
};

float celsius_to_fahrenheit(float c_temp) {
    float f_temp = 0.0;
    f_temp = (1.8 * c_temp) + 32;
    return f_temp;
}

float fahrenheit_to_celsius(float f_temp) {
    float c_temp = 0.0;
    c_temp = (f_temp - 32) / 1.8;
    return c_temp;
}

int which_scale(char *scale) {
    if (strcasecmp(scale, "Fahrenheit") == 0 ||
        strcasecmp(scale, "F") == 0) {
        return SCALE_F;
    }

    if (strcasecmp(scale, "Celsius") == 0 ||
        strcasecmp(scale, "C") == 0) {
        return SCALE_C;
    }

    return -1;
}

int main (int argc, char  **argv) {
    char *temp_raw, *scale_in_raw, *scale_out_raw;
    int scale_in = -1, scale_out = -1;
    float temp_in = 0.0, temp_out = 0.0;

    if (argc < 4) {
        printf("Please specify the temperature and scales.\n");
        exit(1);
    }

    temp_raw = argv[1];
    scale_in_raw = argv[2];
    scale_out_raw = argv[3];

    if (sscanf(temp_raw, "%f", &temp_in) != 1) {
        printf("Invalid input temperature: '%s' degrees\n",
               temp_raw);
        exit(1);
    }

    scale_in = which_scale(scale_in_raw);
    if (scale_in != SCALE_F && scale_in != SCALE_C) {
        printf("Invalid input temperature scale: '%s'\n",
               scale_in_raw);
        exit(1);
    }

    scale_out = which_scale(scale_out_raw);
    if (scale_out != SCALE_F && scale_out != SCALE_C) {
        printf("Invalid output temperature scale: '%s'\n",
               scale_out_raw);
        exit(1);
    }

    if (scale_in == scale_out) {
       printf("Input and output scales are the same\n");
       exit(1);
    }

    if (scale_in == SCALE_C && scale_out == SCALE_F) {
        temp_out = celsius_to_fahrenheit(temp_in);
        printf("%0.2f degrees C is %0.2f degrees F\n",
               temp_in, temp_out);
        exit(0);
    }

    if (scale_in == SCALE_F && scale_out == SCALE_C) {
        temp_out = fahrenheit_to_celsius(temp_in);
        printf("%0.2f degrees F is %0.2f degrees C\n",
               temp_in, temp_out);
        exit(0);
    }

    exit(1);
}

