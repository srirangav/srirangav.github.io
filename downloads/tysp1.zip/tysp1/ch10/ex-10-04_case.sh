#!/bin/sh -v
# Chapter 10 - Section The case Statement
# This script demonstrates using the case statement

FRUIT=kiwi
case "$FRUIT" in
    apple) echo "Apple pie is quite tasty." ;;
    banana) echo "I like banana nut bread." ;;
    kiwi) echo "New Zealand is famous for kiwi." ;;
esac

case "$TERM" in
      *term)
           TERM=xterm ;;
      network|dialup|unknown|vt[0-9][0-9][0-9])
           TERM=vt100 ;;
esac
echo $TERM