#!/bin/sh -v
# Chapter 10 - Section The if Statement
# This script demonstrates the use of the 
# if - then - elif - else - fi statement

if uuencode koala.gif koala.gif > koala.uu ; then
   echo "Encoded koala.gif to koala.uu"
elif rm koala.uu ; then
   echo "Encoding failed, temporary files removed."
else
   echo "An error occured."
fi
