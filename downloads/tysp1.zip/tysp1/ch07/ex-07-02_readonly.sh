#!/bin/sh -v
# Chapter 07 - Section Readonly Variables
# This script tests the readonly keyword

FRUIT=kiwi
readonly FRUIT
echo $FRUIT
FRUIT=cantaloupe
