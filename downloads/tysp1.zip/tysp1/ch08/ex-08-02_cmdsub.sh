#!/bin/sh -v
# Chapter 08 - Section Command Substitution
# This script demonstrates the use of command substitution

DATE=`date`
USERS=`who | wc -l`
UP=`date ; uptime`

echo $DATE
echo $USERS
echo $UP

grep `id -un` /etc/passwd