#!/bin/ksh
# Chapter 08 - Section Arithmetic Subsitution
# This script demonstrates the arithmetic substitution
# facilitiy in ksh/bash. To execute the script under
# bash, change the first line.

foo=$(( ((5 + 3*2) - 4) / 2 ))
echo $foo