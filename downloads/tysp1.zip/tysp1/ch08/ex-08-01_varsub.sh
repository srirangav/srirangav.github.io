#!/bin/sh
# Chapter 08 - Section Variable Substitution
# This script demonstrates the substitution operators

echo "Test 01 - Substituting a Default Value"
PS1=${HOST:-localhost}"$ " ; export PS1 ;
echo $PS1

echo "Test 02 - Assigning a Default Value"
PS1=${HOST:=`uname -n`}"$ " ; export PS1 HOST ;
echo $PS1

echo "Test 03 - Aborting Due to Variable Errors"
: ${HOME:?"Your home directory is undefined."}

echo "Test 04 - Substitution when a Variable is Set"
echo ${DEBUG:+"Debug is active."}