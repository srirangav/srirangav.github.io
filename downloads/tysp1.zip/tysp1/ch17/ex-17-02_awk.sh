#!/bin/sh
# Chapter 17 - Using awk
# This script demonstartes using awk to take pattern specific
# actions.

awk '
    / *\$[1-9][0-9]*\.[0-9][0-9] */ { print $0,"*"; }
    / *\$0\.[0-9][0-9] */ { print ; }
' fruit_prices.txt

