#!/bin/sh
# Chapter 17 - Using awk
# This script demonstartes using numeric expressions in awk
#
# You may have to change /bin/echo to /bin/echo -n in order
# for the output to look the same as in the book.

for i in $@ ;
do
    if [ -f "$i" ] ; then
        /bin/echo "$i\c"
        awk '
            /^ *$/ { x+=1 ; }
            END { printf " %s\n",x; }
        ' "$i"
    else
        echo "ERROR: $i not a file." >&2
    fi
done

