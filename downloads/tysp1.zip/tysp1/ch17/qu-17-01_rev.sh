#!/bin/sh
# Chapter 17 - Answer for Question 1

if [ $# -lt 1 ] ; then
    echo "USAGE: `basename $0` files"
    exit 1
fi

awk '{
    for (i=NF;i>=1;i--) {
        printf("%s ",$i) ;
    }
    printf("\n") ;
}' $@

