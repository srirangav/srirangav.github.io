#!/bin/sh
# Chapter 17 - Using awk
# This script demonstartes using numeric expressions in awk

for i in $@ ;
do
    if [ -f "$i" ] ; then
        awk 'BEGIN { printf "%s\t",FILENAME ; }
            /^ *$/ { x+=1 ; }
            END { ave=100*(x/NR) ; printf " %s\t%3.1f\n",x,ave; }
        ' "$i"
    else
        echo "ERROR: $i not a file." >&2
    fi
done

