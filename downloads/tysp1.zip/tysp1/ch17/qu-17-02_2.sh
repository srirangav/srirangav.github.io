#!/bin/sh
# Chapter 17 - Answer for Question 2

awk -F: '
    $1 == "B" {
        BAL=$NF ; next ;
    }
    $1 == "D" {
        BAL += $NF ;
    }
    ($1 == "C") || ($1 == "W") {
        BAL-=$NF ;
    }
    ($1 == "C") || ($1 == "W") || ($1 == "D") {
        printf "%10-s %8.2f\n",$2,BAL ;
    }
' account.txt ;

