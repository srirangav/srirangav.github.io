#!/bin/sh
# Chapter 17 - Using awk
# This script demonstartes how to use shell variables in an awk command

NUMFRUIT="$1"
if [ -z "$NUMFRUIT" ] ; then NUMFRUIT=75 ; fi

awk '
    $3 <= numfruit  { print ; }
' numfruit="$NUMFRUIT" fruit_prices.txt

