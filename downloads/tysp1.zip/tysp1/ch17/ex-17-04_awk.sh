#!/bin/sh
# Chapter 17 - Using awk
# This script demonstartes using awk to take pattern specific
# actions.

awk '
    ($2 ~ /^\$[1-9][0-9]*\.[0-9][0-9]$/) && ($3 < 75) {
        printf "%s\t%s\t%s\n",$0,"*","REORDER" ;
    }
' fruit_prices.txt ;

