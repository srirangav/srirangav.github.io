#!/bin/sh
# Chapter 21 - Libraries
# This script demonstrates a simple shell library.

echo_error() { echo "ERROR:" $@ >&2 ; }
echo_warning() { echo "WARNING:" $@ >&2 ; }
