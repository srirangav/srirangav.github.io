#!/bin/sh
# Chapter 11 - Reading User Input
# This example demonstrates reading user input in a while loop
# As with the previous example, you may have to change the line:
#
#   /bin/echo "Enter the name of a directory where are your files located:?\c "
#
# to
#
#   /bin/echo -n "Enter the name of a directory where are your files located:?\c "
#
# in order for the output to match the output in the book

RESPONSE=
while [ -z "$RESPONSE" ] ; 
do
    /bin/echo "Enter the name of a directory where are your files located:?\c "
    read RESPONSE
    if [ ! -d "$RESPONSE" ] ; then
        echo "ERROR: Please enter a directory pathname."
        RESPONSE=
    fi
done
