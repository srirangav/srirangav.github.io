#!/bin/sh
# Chapter 11 - The while loop
# This example demonstrates the use of nested while loops
# You may need to change the line:
#
#    /bin/echo "$y \c" 
#
# to
#
#    /bin/echo -n "$y "
#
# on your machine in order to get the same output as shown
# in the book

x=0
while [ "$x" -lt 10 ] ; # this is loop1
do
    y="$x"
    while [ "$y" -ge 0 ] ; # this is loop2
    do
        /bin/echo "$y \c"
        y=`echo "$y - 1" | bc`
    done
    echo
    x=`echo "$x + 1" | bc`
done
