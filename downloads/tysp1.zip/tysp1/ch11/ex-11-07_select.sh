#!/bin/ksh
# Chapter 11 - The select loop
# This example demonstrates using the ksh/bash select loop
#
# The function CompConf has been added to demonstrate the
# behavior of the loop

CompConf() { echo $1 ; }

PS3="Please make a selection => " ; export PS3

select COMPONENT in comp1 comp2 comp3 all none
do
    case $COMPONENT in
        comp1|comp2|comp3) CompConf $COMPONENT ;;
        all) CompConf comp1 
             CompConf comp2
             CompConf comp3
             ;;
        none) break ;;
        *) echo "ERROR: Invalid selection, $REPLY." ;;
    esac
done
