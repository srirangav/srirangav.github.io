#!/bin/bash
# Chapter 11 - The break command
# This example demonstrates how to break out of a nested loop

for i in 1 2 3 4 5
do
    mkdir -p /mnt/backup/docs/ch0${i}
    if [ $? -eq 0 ] ; then
        for j in doc c h m pl sh
        do
            cp $HOME/docs/ch0${i}/*.${j} /mnt/backup/docs/ch0${i}
            if [ $? -ne 0 ] ; then break 2 ; fi
        done
    else
        echo "Could not make backup directory."
    fi
done
