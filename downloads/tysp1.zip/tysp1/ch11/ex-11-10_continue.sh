#!/bin/sh
# Chapter 11 - The continue command
# This example demonstrates the use of the continue command

FILES="$HOME/*"
for FILE in $FILES ;
do
    if [ ! -f "$FILE" ] ; then
        echo "ERROR: $FILE is not a file."
        continue
    fi
    # process the file
done
