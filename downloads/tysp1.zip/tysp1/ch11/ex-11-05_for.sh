#!/bin/sh
# Chapter 11 - The for loop
# This example demonstrates a simple for loop that counts to 10

echo "for loop example 1:"
for i in 0 1 2 3 4 5 6 7 8 9
do 
    echo $i
done

echo "for loop example 2:"
for i in 0 1 2 4 3 5 8 7 9
do 
    echo $i
done

