#!/bin/sh
# Chapter 11 - The Until Loop
# This example demonstrates the use of the until loop

echo "Using an Until loop:"
x=1; 
until [ $x -ge 10 ]
do
    echo $x
    x=`echo "$x + 1" | bc`
done

echo "Using a While loop:"
x=1; 
while [ ! $x -ge 10 ]
do
    echo $x
    x=`echo "$x + 1" | bc`
done
