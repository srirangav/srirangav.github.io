#!/bin/sh
# Chapter 13 - Using File Descriptors
# This example demonstrates the use of file descriptors for reading
# lines from files

#!/bin/sh
if [ $# -ge 1 ] ; then
    for FILE in $@ 
    do
        exec 5<&0 < "$FILE"
        while read LINE ; do echo $LINE ; done
        exec 0<&5 5<&-
    done
fi
