#!/bin/sh
# Chapter 13 - The read command
# This example demonstrates the use of the read command to read
# lines from a file

while read LINE
do
   case $LINE in 
   *root*) echo $LINE ;;
esac
done < /etc/passwd
