#!/bin/sh
# Chapter 23 - Scripting for Portability
# This script provides two functions that you can use to
# determine the version of the operating system your are running.
#
# To use these functions in your scripts you will have to "source"
# this script in using the . command.

getOSName() {
    case `uname -s` in
        *BSD)
            echo bsd ;;
        SunOS)
            case `uname -r` in
                5.*) echo solaris ;;
                  *) echo sunos ;;
            esac
            ;;
        Linux)
            echo linux ;;
        HP-UX)
            echo hpux ;;
        AIX) 
            echo aix ;;
        *) echo unknown ;;
   esac
}

isOS() {
    if [ $# -lt 1 ] ; then
        echo "ERROR: Insufficient Aruments." >&2
        return 1
    fi

    REQ=`echo $1 | tr '[A-Z]' '[a-z]'`
    if [ "$REQ" = "`getOSName`" ] ; then return 0 ; fi
    return 1 
}

