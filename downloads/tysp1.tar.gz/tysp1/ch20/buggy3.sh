#!/bin/sh
# Chapter 20 - Debugging Shell Scripts
# This script demonstrates using shell tracing to debug errors.
# You should execute it as follows:
#
#    /bin/sh -x ./buggy3.sh
#
# in order to find the bug(s). You may also need to change /bin/echo
# to /bin/echo -n to get the same output as shown in the book.

Failed() {
    if [ $1 -ne 0 ] ; then
        echo "Failed. Exiting." ; exit 1 ;
    fi
    echo "Done."
}

YesNo() {
    /bin/echo "$1 (y/n)? \c"
    read RESPONSE
    case $RESPONSE in
        [yY]|[Yy][Ee][Ss]) RESPONSE=y ;;
        [nN]|[Nn][Oo]) RESPONSE=n ;;
    esac
}

YesNo "Make backup"
if [ $RESPONSE = "y" ] ; then

    /bin/echo "Deleting old backups, please wait... \c"
    rm -fr backup > /dev/null 2>&1
    Failed $?

    /bin/echo "Making new backups, please wait... \c"
    cp -r docs backup
    Failed 

fi

