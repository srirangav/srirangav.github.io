#!/bin/sh
# Chapter 20 - Debugging Shell Scripts
# This script demonstrates using debugging hooks.
# To get the debugging output you should execute it as follows:
#
#    DEBUG=true ./buggy3_withdebug.sh
#
# in order to find the bug(s). You may also have to change /bin/echo
# to echo -n in order to get the same output as shown in the book. 

Debug() {
    if [ "$DEBUG" = "true" ] ; then
        if [ "$1" = "on"  -o "$1" = "ON" ] ; then
            set -x
        else
            set +x
        fi
    fi
}

Failed() {
    Debug on
    if [ "$1" -ne 0 ] ; then
        echo "Failed. Exiting." ; exit 1 ;
    fi
    echo "Done."
    Debug off
}

YesNo() {
    Debug on
    /bin/echo "$1 (y/n)? \c"
    read RESPONSE
    case "$RESPONSE" in
        [yY]|[Yy][Ee][Ss]) RESPONSE=y ;;
        *) RESPONSE=n ;;
    esac
    Debug off
}

YesNo "Make backup"
if [ "$RESPONSE" = "y" ] ; then

    /bin/echo "Deleting old backups, please wait... \c"
    rm -r backup > /dev/null 2>&1
    Failed $?

    /bin/echo "Making new backups, please wait... \c"
    cp -r docs backup
    Failed $?
fi
