#!/bin/sh
# Chapter 21 - Libraries
# This script demonstrates using the messages.sh library. It has
# been slightly modified from the version in the book so that it
# can be run from the current directory.

. ./messages.sh
MSG="hello"
echo_error $MSG
