#!/bin/sh
# Chapter 15 - Answer to Question 1
# This function prints out the pid for the named process
# On linux/bsd you will need to change the value of $PSCMD
# to:
#
#    PSCMD="/bin/ps -auwx"
#
# You will need to "source" this script into your environment
# using the . command.

lspids() {

    USAGE="Usage: lspids [-h] process"
    HEADER=false
    PSCMD="/bin/ps -ef"

    case "$1" in
        -h) HEADER=true ; shift ;;
    esac

    if [ -z "$1" ] ; then
        echo $USAGE ;
        return 1 ;
    fi

    if [ "$HEADER" = "true" ] ; then
        $PSCMD 2> /dev/null | head -�n 1 ;
    fi

    $PSCMD 2> /dev/null | grep "$1"| grep -v grep
}

