#!/bin/sh
# Chapter 15 - Answer to Question 2
# This function prints out the pid for the named process
# On linux/bsd you will need to change the value of $PSCMD
# to:
#
#    PSCMD="/bin/ps -auwx"
# 
# and you will need to change the value of $SORTCMD to:
#
#    SORTCMD="sort -rn"
#
# You will need to "source" this script into your environment
# using the . command.

lspids () 
{ 
    USAGE="Usage: lspids [-h|-s] process";
    HEADER=false;
    SORT=false;
    PSCMD="/bin/ps -ef";
    SORTCMD="sort -rn -k 2,2";
    for OPT in $@;
    do
        case "$OPT" in 
            -h)
                HEADER=true;
                shift
            ;;
            -s)
                SORT=true;
                shift
            ;;
            -*)
                echo $USAGE;
                return 1
            ;;
        esac;
    done;
    if [ -z "$1" ]; then
        echo $USAGE;
        return 1;
    fi;
    if [ "$HEADER" = "true" ]; then
        $PSCMD | head -1;
    fi;
    if [ "$SORT" = "true" ]; then
        $PSCMD 2> /dev/null | grep "$1" | grep -v grep | $SORTCMD;
    else
        $PSCMD 2> /dev/null | grep "$1" | grep -v grep;
    fi
}

