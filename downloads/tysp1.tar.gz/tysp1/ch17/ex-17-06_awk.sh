#!/bin/sh
# Chapter 17 - Using awk
# This script demonstartes using numeric expressions in awk

for i in $@ ;
do
    if [ -f $i ] ; then
        echo $i
        awk ' /^ *$/ { x=x+1 ; print x ; }' $i
    else
        echo "ERROR: $i not a file." >&2
    fi
done
