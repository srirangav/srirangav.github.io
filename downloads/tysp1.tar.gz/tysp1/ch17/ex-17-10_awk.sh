#!/bin/sh
# Chapter 17 - Using awk
# This script demonstrates the use of the for loop in awk

awk '{
    for (x=1;x<=NF;x+=1) {
        printf "%s  ",$x ;
    }
    printf "\n" ;
}' fruit_prices.txt

