#!/bin/sh
# Chapter 19 - Working with Signals
# This script demonstrates how to catch and send signals

if [ $# -lt 1 ] ; then
    echo "USAGE: `basename $0` command."
    exit 0
fi

Init() {
    printf "INFO: Initializing... "

    # check if the last backgrounded pid is valid, if it is
    # try an kill it.

    kill -0 $! 2> /dev/null; 
    if [ $? -eq 0 ] ; then 
        kill $! > /dev/null 2>&1
        if [ $? -ne 0 ] ; then
            echo "ERROR: Already running as pid $!. Exiting."
            exit 1
        fi
    fi

    # start a new program in the background

    $PROG &
    printf "Done.\n"
}

CleanUp() {
    kill -9 $! ; exit 2 ; 
}

# main()

trap CleanUp 2 3 15
trap Init 1

PROG=$1
Init

while : ;
do    
    wait $!
    $PROG &
done

