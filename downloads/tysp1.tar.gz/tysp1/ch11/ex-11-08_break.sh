#!/bin/sh
# Chapter 11 - Infinite loops
# This example demonstrates how the while loop can be used to
# gather user input. The process function has been added to
# demonstrate the execution of the case statement

process () { echo $@ ; }

while :
do
    read CMD
    case $CMD in
        [qQ]|[qQ][uU][iI][tT]) break ;;
        *) process $CMD ;;
     esac
done
