#!/bin/sh
# Chapter 11 - Manipulating a set of files
# This example demonstrates how to use the for loop to copy files
#
# This example may fail on your system if you do not have some of
# the files or directories that are referenced. This example has
# been changed slightly from the version in the book for greater
# compatibility.

cd $HOME 
for FILE in .bash*
do
    cp $FILE ${HOME}/public_html
    chmod a+r ${HOME}/public_html/${FILE}
done
