#!/bin/sh
# Chapter 11 - The while loop
# This example demonstrates a simple while loop that 
# counts to 10
x=0
while [ $x -lt 10 ]
do
    echo $x
     x=`echo "$x + 1" | bc`   
done
