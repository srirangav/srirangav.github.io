#!/bin/ksh -v
# Chapter 07 - Section Array Variables
# This script demonstrates using array variables in ksh
# To use this script with bash, change the first line

FRUIT[0]=apple
FRUIT[1]=banana
FRUIT[2]=orange
echo ${FRUIT[2]}
echo ${FRUIT[*]}
FRUIT[3]="passion fruit"
echo ${FRUIT[@]}
