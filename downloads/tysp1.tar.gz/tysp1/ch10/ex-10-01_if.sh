#!/bin/sh -v
# Chapter 10 - Section The if Statement
# This script demonstrates the use of the 
# if - then - else - fi construct.

if uuencode koala.gif koala.gif > koala.uu ; then
   echo "Encoded koala.gif to koala.uu"
else
   echo "Error encoding koala.gif"
fi
