#!/bin/sh -v
# Chapter 10 - Section Using Test
# This script demonstrates the use of the 
# test or [ command

if [ -z "$FRUIT_BASKET" ] ; then 
    echo "Your fruit basket is empty" ; 
else 
    echo "Your fruit basket as the following fruit: $FRUIT_BASKET"
fi

if [ "$FRUIT" = apple ] ; then
    echo "An apple a day keeps the doctor away."
else
    echo "You must like doctors, your fruit $FRUIT is not an apple."
fi


