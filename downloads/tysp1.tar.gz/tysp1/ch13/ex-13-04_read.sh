#!/bin/sh
# Chapter 13 - The read command
# This example demonstrates the use of the read command

YN=yes
printf "Do you want to play a game [$YN]? "
read YN
: ${YN:=yes}
case $YN in
    [yY]|[yY][eE][sS]) exec xblast ;;
    *) echo "Maybe later." ;;
esac

