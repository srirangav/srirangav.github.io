#!/bin/sh
# Chapter 13 - Input/Output
# This example demonstrates using escapes in the echo command
# 
# You make have to change:
#
#  /bin/echo
#
# to 
#
#  /bin/echo -n
#
# in order to get your output to match the example in the book

DIRS_TO_MAKE="fruit/basket"
FILES="fruit/apple fruit/banana fruit/orange fruit/pear fruit/plum fruit/peach"
DEST="fruit/basket"

/bin/echo "Making directories, please wait...\t\c"
for i in ${DIRS_TO_MAKE} ; do mkdir -p $i ; done
echo "Done."

/bin/echo "Copying files, please wait\t\c"
for i in ${FILES} ; do cp $i $DEST && /bin/echo ".\c" ; done
/bin/echo "\tDone."
