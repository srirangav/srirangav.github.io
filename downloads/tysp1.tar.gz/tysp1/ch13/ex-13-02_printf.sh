#!/bin/sh
# Chapter 13 - Using printf
# This example demonstrates the use of the printf command

/bin/echo "File Name\tType"

for i in *;
do
    /bin/echo "$i\t\c"
    if [ -d $i ]; then
        echo "directory"
    elif [ -h $i ]; then
        echo "symbolic link"
    elif [ -f $i ]; then
        echo "file"
    else
        echo "unknown"
    fi
done
