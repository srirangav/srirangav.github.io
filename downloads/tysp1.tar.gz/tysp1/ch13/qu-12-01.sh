#!/bin/sh
# Answer to Chapter 13 Question 1

if [ $# -lt 2 ] ; then 
    echo "ERROR: Insufficient arguments." ; 
    exit 1 ;
fi

case "$1" in
    -o) printf "%o\n" "$2" ;;
    -x) printf "%x\n" "$2" ;;
    -e) printf "%e\n" "$2" ;;
    *) echo "ERROR: Unknown conversion, $1!" ;;
esac

