#!/bin/sh

_ECHO=/bin/echo
_N=
_C="\c"
ECHOOUT=`$_ECHO "hello $_C"`
if [ "$ECHOOUT" = "hello \c" ] ; then
    _N="-n"
    _C=
fi
export _ECHO _N _C

echo_prompt() {  $_ECHO $_N $@ $_C ; }

