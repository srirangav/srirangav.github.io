#!/bin/sh -v

echo "I drink lemonade in the summer" > lemonade
cat lemonade
ln lemonade summer_drink
cat summer_drink
mv summer_drink ..
cat ../summer_drink

