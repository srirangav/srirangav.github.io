#!/bin/sh -v

echo Persimmons are bitter until they ripen > persimmon
ln -s persimmon bitter
cat bitter
mv bitter ..
cat ../bitter
ls -l ../bitter

