#!/bin/sh -v

echo Plums were plentiful this year > plums
ln -s plums plentiful
cat plentiful
rm plums
cat plentiful
ls -l plentiful

