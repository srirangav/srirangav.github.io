#!/bin/sh

if [ -n "$FRUIT_BASKET" ] ; then
   echo "Your fruit basket contains: $FRUIT_BASKET"
else
   echo "Your fruit basket is empty"
fi
