#!/bin/sh

if uuencode cherry.gif cberry.gif > cherry.uu then
   echo "Encoded cherry.gif to cherry.uu"
else
   echo "Error encoding cherry.gif"
fi
