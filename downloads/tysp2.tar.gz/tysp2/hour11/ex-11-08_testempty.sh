#!/bin/sh

if [ -z "$FRUIT_BASKET" ] ; then
   echo "Your fruit basket is empty"
else
   echo "Your fruit basket contains: $FRUIT_BASKET"
fi
