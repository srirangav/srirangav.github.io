#!/bin/sh

date | tee now
