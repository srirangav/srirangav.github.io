#!/bin/sh

USAGE="Usage: `basename $0` [-v] [-x] [-f] [filename] [-o] [filename]";

VERBOSE=false
EXTRACT=false

while getopts f:o:x:v OPTION ; do
    case "$OPTION" in
        f) INFILE="$OPTARG" ;;
        o) OUTFILE="$OPTARG" ;;
        v) VERBOSE=true ;;
        x) EXTRACT=true ;;
       \?) echo "$USAGE" ;
           exit 1
           ;;
    esac
done

shift `echo "$OPTIND - 1" | bc`

if [ -z "$1" -a -z "$INFILE" ] ; then
    echo "ERROR: Input file was not specified."
    exit 1
fi
if [ -z "$INFILE" ] ; then INFILE="$1" ; fi

: ${OUTFILE:=${INFILE}.uu}

if [ -f "$INFILE" ] ; then
    if [ "$EXTRACT" = "true" ] ; then
        if [ "$VERBOSE" = "true" ] ; then
            echo "uudecoding $INFILE... \c"
        fi
        uudecode "$INFILE" ; RET=$?
    else
        if [ "$VERBOSE" = "true" ] ; then
            echo "uuencoding $INFILE to $OUTFILE... \c"
        fi
        uuencode "$INFILE" "$INFILE" > "$OUTFILE" ; RET=$?
    fi

    if [ "$VERBOSE" = "true" ] ; then
        MSG="Failed" ; if [ $RET -eq 0 ] ; then MSG="Done." ; fi
        echo $MSG
    fi
else
    echo "ERROR: $INFILE is not a file."
fi
exit $RET

