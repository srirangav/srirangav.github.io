#!/bin/sh
  
Failed() {
  if [ $1 -ne 0 ] ; then
     echo "Failed. Exiting." ; exit 1 ;
   fi
   echo "Done."
}
  
echo "Deleting old backups, please wait... \c"
rm -r backup > /dev/null 2>&1
 Failed $?
  
echo "Make backup (y/n)? \c"
read RESPONSE
case $RESPONSE in
    [yY]|[Yy][Ee][Ss]|*) 
       echo "Making backup, please wait... \c"
       cp -r docs backup
       Failed
    [nN]|[Nn][Oo])
       echo "Backup Skipped." ;;
esac

