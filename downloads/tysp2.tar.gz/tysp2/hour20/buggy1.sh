#!/bin/sh

YN=y
if [ $YN = "yes" ] 
   echo "yes"
fi
