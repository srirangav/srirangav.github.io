#!/bin/sh

orange () {
   echo "Now in orange"
   banana               # call the function named banana
}

banana () {
   echo "Now in banana"
}

orange

