_popd_helper() {

    # set the directory to pop to the first argument, if 
    # this directory is empty, issue an error and return 1
    # otherwise get rid of POPD from the arguments

    POPD="$1"
    if [ -z "$POPD" ] ; then
        echo "ERROR: The directory stack is empty." >&2
        return 1
    fi
    shift

    # if any more arguments remain, reinitalize the directory
    # stack, and then update it with the remaining items, 
    # otherwise set the directory stack to null

    if [ -n "$1" ] ; then 
        _DIR_STACK="$1" ; 
        shift ;
        for i in $@ ; do _DIR_STACK="$_DIR_STACK:$i" ; done
    else
        _DIR_STACK=
    fi

    # if POPD is a directory cd to it, otherwise issue
    # an error message

    if [ -d "$POPD" ] ; then
        cd "$POPD" > /dev/null 2>&1
        if [ $? -ne 0 ] ; then
            echo "ERROR: Could not cd to $POPD." >&2
        fi
        pwd
    else
        echo "ERROR: $POPD is not a directory." >&2
    fi

    export _DIR_STACK
    unset POPD
}

popd() {
    OLDIFS="$IFS"
    IFS=:
    _popd_helper $_DIR_STACK
    IFS="$OLDIFS"
}

