#!/bin/sh
lsl() { ls -l ; }
cd "$1" && lsl

