#!/bin/sh 

reverse() {
   if [ $# -gt 0  ] ; then
      typeset arg="$1"
      shift
      reverse "$@"
      echo "$arg "
   fi
}

reverse "$@"

