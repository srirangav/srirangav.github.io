#!/bin/sh

readPass () {
    PASS=""                      # clear password
    echo -n "Enter Password: "   # print the prompt
    stty -echo                   # turn off terminal echo to prevent peeping!
    read PASS                    # read the password
    stty echo                    # restore terminal echo
    echo                         # printout a new line to make output nice
}

readPass
echo Password is $PASS

