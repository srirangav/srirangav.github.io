inPath () {
   OLDIFS="$IFS"
   IFS=:
   RC=1
   for i in $PATH
   do
      if [ -x "$i/$1" ] ; then
         echo "$i/$1"
         RC=0
         break
      fi
   done
   IFS="$OLDIFS"
   return $RC
}

