mkdirp () {
   OLDIFS="$IFS"
   IFS=/
   for i in $@
   do
      if [ -z "$i" ] ; then i="/" ; fi

      if [ -z "$parent" ] ; then
         parent="$i"
      elif [ "$parent" = "/" ] ; then
         parent="$parent$i"
      else
         parent="$parent/$i"
      fi 

      if [ ! -d "$parent" ] ; then

         if [ ! -e "$parent" ] ; then
            mkdir "$parent"
            if [ $? -ne 0 ] ; then
               echo "mkdir $parent failed."
               IFS="$OLDIFS"
            fi
         else
            echo "$parent exists, but is not a dir."
            IFS="$OLDIFS"
            return 1
         fi
     fi

   done
   IFS="$OLDIFS"
   return 0
}

