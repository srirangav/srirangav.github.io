Prompt_RESPONSE() {

    if [ $# -lt 1 ] ; then
        echo "ERROR: Insufficient arguments." >&2
        return 1
    fi

    RESPONSE=
    while [ -z "$RESPONSE" ]
    do
        echo "$1 \c "
        read RESPONSE
    done

    export RESPONSE
}

