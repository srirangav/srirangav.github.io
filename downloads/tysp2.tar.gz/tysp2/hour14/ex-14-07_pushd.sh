pushd() {

   # set REQ to the first argument (if given, otherwise use .)

   REQ="${1:-.}"

   # if $REQ is not a directory, print an error and return

   if [ ! -d "$REQ" ] ; then
      echo "ERROR: $REQ is not a directory." 1>&2
      return 1
   fi

   # if we can cd to $REQ, update _DIR_STACK and print it out
   # otherwise print an error and return

   if cd "$REQ" > /dev/null 2>&1 ; then
      _DIR_STACK="`pwd`:$_DIR_STACK" ; export _DIR_STACK ;
      dirs
   else
      echo "ERROR: Cannot change to directory $REQ." >&2
      return 1
   fi

   unset REQ
}

