#!/bin/sh

ls -l | awk '$1 !~ /total/ { printf "%-32s %s\n",$9,$5 ; }'
