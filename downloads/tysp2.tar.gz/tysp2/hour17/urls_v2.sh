#!/bin/sh
for i in $@ ;
do
    if [ -f "$i" ] ; then
        echo "$i\c"
        awk '
            /^ *$/ { x+=1 ; next; }
            END { printf " %s\n",x; }
        ' "$i"
    else
        echo "ERROR: $i not a file." >&2
    fi
done

