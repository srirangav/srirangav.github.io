#!/bin/sh
awk '
    / *\$[1-9][0-9]*\.[0-9][0-9] */ { print $0,"*"; }
    / *\$0\.[0-9][0-9] */ { print ; }
' fruit_prices.txt
