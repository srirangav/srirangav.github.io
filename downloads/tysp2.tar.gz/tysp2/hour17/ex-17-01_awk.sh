#!/bin/sh

awk '{ print $1 $3 ;}' fruit_prices.txt
