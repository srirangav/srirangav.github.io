# Name: printError
# Desc: prints an message to STDERR
# Args: $@ -> message to print

printError () {
    echo "ERROR:   $@" 1>&2
}

# Name: printWarning
# Desc: prints an message to STDERR
# Args: $@ -> message to print

printWarning () {
    echo "WARNING: $@" 1>&2
}

# Name:    promptYESNO
# Desc:    Asks a yes/no question
# Args:    $1 -> The prompt
#          $2 -> The default answer (optional)
# Globals: YESNO -> set to the users response y for yes, n for no

promptYESNO () {

   YESNO=""

   if [ $# -lt 1 ] ; then
      return 1
   fi

   _YNPROMPT="$1 (y/n)? "
   _YNDEFANS=""
 
   case "$2" in
      [yY]|[yY][eE][sS]) _YNDEFANS="y" ;;
      [nN]|[nN][oO])     _YNDEFANS="n" ;;
   esac

   _YNPROMPT="$_YNPROMPT${_YNDEFANS:+[$_YNDEFANS] }"
       
   while :
   do
      printf "$_YNPROMPT"
      read YESNO
      case "${YESNO:-$_YNDEFANS}" in
         [yY]|[yY][eE][sS])
             YESNO="y" 
             break
             ;;
         [nN]|[nN][oO])
             YESNO="n"
             break
             ;;
         *) YESNO="" ;;
      esac
   done

   unset _YNPROMPT _YNDEFANS
   export YESNO
   return 0
}

# Name:    promptRESPONSE
# Desc:    Asks a question
# Args:    $1 -> The prompt
#          $2 -> The default answer (optional)
# Globals: RESPONSE -> set to the users response

promptRESPONSE () {

   RESPONSE=""
   
   if [ $# -lt 1 ] ; then
      return 1
   fi

   _RDEFANS="${2:+$2}"
   _RPROMPT="$1? ${_RDEFANS:+[$_RDEFANS] }"

   while :
   do
      printf "$_RPROMPT"
      read RESPONSE
      RESPONSE="${RESPONSE:-$_RDEFANS}"
      if [ -n "$RESPONSE" ] ; then 
         break
      fi
      RESPONSE=""
   done

   unset _RDEFANS _RPROMPT
   export RESPONSE
   return 0 
}

# Name: getSpaceFree
# Desc: Outputs the space avail for a directory
# Args: $1 -> The directory to check

getSpaceFree () {
   if [ $# -ge 1 ] ; then
      df -k "$1" 2> /dev/null | awk 'NR != 1 { print $4; }'
      return $?
   fi
   return 1
}

# Name: getSpaceUsed
# Desc: output the space used for a directory
# Args: $1 -> The directory to check

getSpaceUsed () {
   if [ -d "$1" ] ; then
      du -sk "$1" | awk '{ print $1; }'
      return $?
   fi
   return 1
}

# Name: getPID
# Desc: Outputs a list of process id matching $1
# Args: $1 -> the command name to look for

getPID() {

    if [ $# -lt 1 ] ; then
        return 1
    fi

    PSOPTS="-ef"

    /bin/ps $PSOPTS | grep "$1" | grep -v grep | awk '{ print $2; }'
}

# Name: getUID
# Desc: outputs a numeric user id
# Args: $1 -> a user name (optional)

getUID() {
    id $1 | sed -e 's/(.*$//' -e 's/^uid=//'
}

# Name: toLower
# Desc: changes an input string to lower case
# Args: $@ -> string to change

toLower() {
    echo $@ | tr '[A-Z]' '[a-z]' ;
}

# Name: toUpper
# Desc: changes an input string to upper case
# Args: $@ -> string to change

toUpper() {
    echo $@ | tr '[a-z]' '[A-Z]'
}

