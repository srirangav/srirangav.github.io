#!/bin/sh

PROG="$1"
if [ "$PROG" = "" ] ; then
    echo "Usage: $0 cmd."
    exit 1
fi

Init() {
    if [ "$!" != "" -a "$!" != "0" ] ; then
        if kill -0 "$!" > /dev/null 2>&1 ; then
            kill "$!" > /dev/null 2>&1 || return
        fi
    fi
    $PROG &
}

CleanUp() {
     if [ "$!" != "" -a "$!" != "0" ] ; then
        kill -9 "$!" > /dev/null 2>&1
     fi
     exit 2
}

trap CleanUp 2 3 15
trap Init 1

while : ;
do
   if [ "$!" != "" -a "$!" != "0" ] ; then
        wait "$!"
   fi
   $PROG &
done

exit 0

