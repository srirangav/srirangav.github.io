#! /bin/sh

AlarmHandler() {
    echo "Got SIGALARM, cmd took too long."
    KillSubProcs
    exit 14
}

IntHandler() {
    echo "Got SIGINT, user interrupt."
    KillSubProcs
    exit 2
}

KillSubProcs() {
    kill ${CHPROCIDS:-$!}
    if [ $? -eq 0 ] ; then echo "Sub-processes killed." ; fi
}

SetTimer() {
    DEF_TOUT=${1:-10};
    if [ $DEF_TOUT -ne 0 ] ; then
        sleep $DEF_TOUT && kill -s 14 $$ &
        CHPROCIDS="$CHPROCIDS $!"
        TIMERPROC=$!
    fi
}

UnsetTimer() { 
    kill $TIMERPROC 
}

# main()

trap AlarmHandler 14
trap IntHandler 2

SetTimer 15
$PROG &
CHPROCIDS="$CHPROCIDS $!"
wait $!
UnsetTimer
echo "All Done."
exit 0

