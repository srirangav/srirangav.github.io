#!/bin/sh

for i in 0 1 2 4 3 5 7 8 9
do
   echo $i
done
