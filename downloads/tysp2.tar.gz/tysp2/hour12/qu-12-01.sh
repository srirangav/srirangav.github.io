#!/bin/sh

# NOTE: If the output includes lines that look like:
#
# 0 \c
# 1 \c
# 2 \c
# 3 \c
# 4 \c
# 5 \c
# 6 \c
# 7 \c
# 8 \c
# 9 \c
#
# You should replace the line:
#
#    echo "$y \c"
#
# with:
#
#    echo -n "$y"

x=0
while [ $x -lt 10 ]
do
    x=$(($x+1))
    y=0
    while [ $y -lt $x ] 
    do
        echo "$y \c"
        y=$(($y+1))
    done
    echo
done

