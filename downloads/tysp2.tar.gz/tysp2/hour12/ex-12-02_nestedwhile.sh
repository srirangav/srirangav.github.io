#!/bin/sh

x=0
while [ "$x" -lt 10 ] ; # this is loop1
do
   y="$x"
   while [ "$y" -ge 0 ] ; # this is loop2
   do
      printf "$y "
      y=`expr $y - 1`
   done
   echo
   x=`expr $x + 1`
done
