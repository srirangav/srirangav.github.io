#!/bin/sh

while :
do
    read CMD
    case $CMD in
        [qQ]|[qQ][uU][iI][tT]) break ;;
        *) $CMD ;;
     esac
done

