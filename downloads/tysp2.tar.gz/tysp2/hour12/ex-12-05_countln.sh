#!/bin/sh

if [ -f "$1" ] ; then
   i=0
   while read LINE
   do
      i=`expr $i + 1`
   done < "$1"
   echo $i
fi
