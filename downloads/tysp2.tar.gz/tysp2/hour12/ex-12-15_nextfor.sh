#!/bin/sh

# NOTE: Remove the following line if you want this script
#       to actually execute the commands

set -nv

for i in 1 2 3 4 5
do
    mkdir -p /mnt/backup/docs/ch0${i}
    if [ $? -eq 0 ] ; then
        for j in doc c h m pl sh
        do
            cp $HOME/docs/ch0${i}/*.${j} /mnt/backup/docs/ch0${i}
            if [ $? -ne 0 ] ; then break 2 ; fi
        done
    else
        echo "Could not make backup directory."
    fi
done

