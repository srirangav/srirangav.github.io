sgrep() {
    if [ $# -lt 2 ] ; then 
        echo "USAGE: sgrep pattern files" >&2
        exit 1
    fi

    PAT="$1" ; shift ;    

    for i in $@ ; 
    do
        if [ -f "$i" ] ; then
            sed -n "/$PAT/p" $i
        else
            echo "ERROR: $i not a file." >&2
        fi
    done
    
    return 0
}

