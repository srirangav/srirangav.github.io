# NOTE: For LINUX Linux and FreeBSD, change the variable SORTCMD to
#
#  SORTCMD="sort -rn"
#
# instead of
#
#  SORTCMD="sort -rn -k 2,2"
#
# You will also need to change the variable PSCMD from
#
#  PSCMD="/bin/ps -ef"
#
# to
#
#  PSCMD="/bin/ps -auwx"


lspids () 
{ 
    USAGE="Usage: lspids [-h|-s] process";
    HEADER=false;
    SORT=false;
    PSCMD="/bin/ps -ef";
    SORTCMD="sort -rn -k 2,2";
    for OPT in $@;
    do
        case "$OPT" in 
            -h)
                HEADER=true;
                shift
            ;;
            -s)
                SORT=true;
                shift
            ;;
            -*)
                echo $USAGE;
                return 1
            ;;
        esac;
    done;
    if [ -z "$1" ]; then
        echo $USAGE;
        return 1;
    fi;
    if [ "$HEADER" = "true" ]; then
        $PSCMD | head -1;
    fi;
    if [ "$SORT" = "true" ]; then
        $PSCMD 2> /dev/null | grep "$1" | grep -v grep | $SORTCMD;
    else
        $PSCMD 2> /dev/null | grep "$1" | grep -v grep;
    fi
}

