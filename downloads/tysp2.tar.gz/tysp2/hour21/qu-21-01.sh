################################################
# Name: toLower
# Desc: changes an input string to lower case
# Args: $@ -> string to change
################################################

toLower() {
    echo $@ | tr '[A-Z]' '[a-z]' ;
}

