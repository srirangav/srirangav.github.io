################################################
# Name: toUpper
# Desc: changes an input string to upper case
# Args: $@ -> string to change
################################################

toUpper() {
    echo $@ | tr '[a-z]' '[A-Z]'
}

