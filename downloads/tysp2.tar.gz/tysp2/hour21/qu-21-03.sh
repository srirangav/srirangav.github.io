################################################
# Name: isSpaceAvailable
# Desc: returns true (0) if space available
# Args: $1 -> The directory to check
#       $2 -> The amount of space to check for
################################################

isSpaceAvailable() {

    if [ $# -lt 2 ] ; then
        printERROR "Insufficient Arguments."
        return 1
    fi

    if [ ! -d "$1" ] ; then
        printERROR "$1 is not a directory."
        return 1
    fi

    if [ `getSpaceFree "$1"` -gt "$2" ] ; then
        return 0
    fi

    return 1
}

