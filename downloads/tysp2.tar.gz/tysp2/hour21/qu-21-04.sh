################################################
# Name: isSpaceAvailable
# Desc: returns true (0) if space available
# Args: $1 -> The directory to check
#       $2 -> The amount of space to check for
#       $3 -> The units for $2 (optional)
#                 k for kilobytes
#                 m for megabytes
#                 g for gigabytes
################################################

isSpaceAvailable() {

    if [ $# -lt 2 ] ; then
        printERROR "Insufficient Arguments."
        return 1
    fi

    if [ ! -d "$1" ] ; then
        printERROR "$1 is not a directory."
        return 1
    fi

    SPACE_MIN="$2"

    case "$3" in
        [mM]|[mM][bB])
            SPACE_MIN=`echo "$SPACE_MIN * 1024" | bc` ;;
        [gG]|[gG][bB])
            SPACE_MIN=`echo "$SPACE_MIN * 1024 * 1024" | bc` ;;
    esac

    if [ `getSpaceFree "$1"` -gt "$SPACE_MIN" ] ; then
        return 0
    fi

    return 1
}

